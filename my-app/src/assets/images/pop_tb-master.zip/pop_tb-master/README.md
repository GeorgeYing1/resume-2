# Installation instructions

Clone the repository or download and extract in the zip.

- Browse to [chrome://extensions](chrome://extensions/)
- Tick to enable `Developer mode` in the upper-right
- Click `Load unpacked extension...` and browse to the directory wherever you have stored the pop_tb sources
- Highlight the chrome directory and press `Select`
